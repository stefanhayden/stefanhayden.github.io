package main

import "testing"
import "os"
import "fmt"
import "github.com/stretchr/testify/assert"

func TestMultipleInstruments(t *testing.T) {
  var instruments = []string{"kick", "hihat", "midtom"}
  result := formatInstruments(instruments)
  correctResult := "kick+hihat+midtom";
  assert.Equal(t, result, correctResult, "formatInstruments was incorrect for multiple instruments.")
}

func TestOneInstruments(t *testing.T) {
  var instruments = []string{"kick"}
  result := formatInstruments(instruments)
  correctResult := "kick";
  assert.Equal(t, result, correctResult, "formatInstruments was incorrect for one instruments.")
}

func TestZeroInstruments(t *testing.T) {
  var instruments = []string{}
  result := formatInstruments(instruments)
  correctResult := "_";
  assert.Equal(t, result, correctResult, "formatInstruments was incorrect for zero instruments.")
}

func TestBmpInterval(t *testing.T) {
  result := bmpInterval(128)
  correctResult := 468750;
  assert.Equal(t, result, correctResult, "bmpInterval was incorrect.")
}

func TestGetSong(t *testing.T) {
  result := getSong("song.fixture.json");

  correctTitle := "Four on the floor";

  assert.Equal(t, result.Title, correctTitle, "Title of song should match.")

  Loop := [][]string{
    {"kick"},
    {},
    {"hihat"},
    {},
    {"kick", "snare"},
    {},
    {"hihat"},
  }

  assert.Equal(t, result.Loop, Loop, "Loops should be equal.")
}

func TestGetFlagValuesDefault(t *testing.T) {
  bpm, songLocation, songLength := getFlagValues();

  assert.Equal(t, bpm, 128, "bpm should be default value.")
  assert.Equal(t, songLocation, "song.json", "songLocation should be default value.")
  assert.Equal(t, songLength, 30, "songLength should be default value.")
}
