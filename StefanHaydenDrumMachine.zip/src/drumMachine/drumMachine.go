package main

import "fmt"
import "time"
import "os"
import "io/ioutil"
import "encoding/json"
import "flag"

type Song struct {
  Title string 				`json:"title"`
  bpm   int 					`json:"bpm"`
  Loop  [][]string    `json:"loop"`
}

func bmpInterval(bpm int) int {
	secondsInMinute := 60;
	millisecondsInMinute := secondsInMinute * 1000;
	microsecondsInMinute := millisecondsInMinute * 1000;

	return microsecondsInMinute / bpm;
}

func getTicker(bpm int) *time.Ticker {
	ticker := time.NewTicker(time.Duration(bmpInterval(bpm)) * time.Microsecond)

	return ticker;
}

func getSong(song string) Song {
	jsonFile, err := os.Open(song)
	if err != nil {
    fmt.Println("Can not find that file!")
		os.Exit(2)
	}
	defer jsonFile.Close()

	byteValue, _ := ioutil.ReadAll(jsonFile)

	var result Song
	json.Unmarshal(byteValue, &result)

	return result;
}

func getFlagValues() (int, string, int) {
	bpmPtr := flag.Int("bpm", 128, "Beats per minute")
	songPtr := flag.String("song", "song.json", "Location of song file")
	songLengthPtr := flag.Int("length", 30, "Length of song in seconds")
	fmt.Println("args in app", os.Args);
	flag.Parse()

	bpm := *bpmPtr;
	songLocation := *songPtr;
	songLength := *songLengthPtr;
	Error := false;
fmt.Println("BPM ", bpm);
	if (bpm < 1) {
		fmt.Println("Beats per minute must be greater then 0");
		Error = true;
	}

	if (songLength < 1) {
		fmt.Println("Song length must be greater then 0");
		Error = true;
	}

	if (Error) {
		os.Exit(1)
	}

	return bpm, songLocation, songLength
}

func formatInstruments(instruments []string) string {
	result := "";
	if (len(instruments) == 0) {
		// if no instruments then this will respresent a empty beat
		result = "_"
	} else {
		for i := 0; i < len(instruments); i++ {
			result = result + instruments[i];
			if ((i + 1) < len(instruments)) {
				// if multiple instruments in a single
				// beat put a + between them
				joiner := "+"
				result = result + joiner;
			}
		}
	}

	return result;
}

func main() {
	bpm, songLocation, songLength := getFlagValues();

	ticker := getTicker(bpm);
	song := getSong(songLocation);

	fmt.Println("Song Title: ", song.Title);
	fmt.Println("Beats Per Minute: ", bpm);

	go func() {
			beat := 0;
			for range ticker.C {
				// break between beats
				fmt.Print("|")

				// output instrument for that beat
				fmt.Print(formatInstruments(song.Loop[beat]));

				// if we reached the end of the song go back to zero to loop it
				if (beat + 1 < len(song.Loop)) {
					beat++;
				} else {
					beat = 0;
				}
			}
	}();

	time.Sleep(time.Duration(songLength) * time.Second)
	ticker.Stop()
}
