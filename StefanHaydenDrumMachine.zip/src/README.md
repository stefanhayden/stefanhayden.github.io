# DrumMachine

to run the drumMachine just run the `drumMachine.exe`.

## Flags
With flas you can set new beats per minute, song length, or a path to a new song file.

- -bpm int
    - Beats per minute (default `128`)
- -length int
    - Length of song in seconds (default `30`)
- -song string
    - Location of song file (default `song.json`)

## Development
In the `DrumMachine` dir run  `go build` to get a new `.exe`

## Testing
In the `DrumMachine` dir run  `go test` to run unit tests.
